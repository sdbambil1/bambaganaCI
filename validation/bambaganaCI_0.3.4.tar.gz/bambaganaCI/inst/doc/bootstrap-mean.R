## -----------------------------------------------------------------------------
library(bambaganaCI)
set.seed(1998)
x <- rnorm(30, mean = 2, sd = 1)
standard <- mean_t_ci(x)
set.seed(1998)
bootstrap <- bootstrap_mean_ci(x, B = 2000)
standard
bootstrap

## -----------------------------------------------------------------------------
coef(bootstrap)
confint(bootstrap)
rbind(as.data.frame(standard), as.data.frame(bootstrap))
bootstrap$diagnostics

## -----------------------------------------------------------------------------
set.seed(1998)
interval_90 <- bootstrap_mean_ci(x, conf = 0.90)
confint(interval_90)

## -----------------------------------------------------------------------------
methods <- c("percentile", "basic", "normal", "bca")
comparison <- lapply(methods, function(method) {
  set.seed(1998)
  as.data.frame(bootstrap_mean_ci(x, B = 2000, method = method))
})
do.call(rbind, comparison)

## -----------------------------------------------------------------------------
set.seed(1998)
tiny <- bootstrap_mean_ci((1:10) * 1e-200)
set.seed(1998)
ordinary <- bootstrap_mean_ci(1:10)
c(tiny_SE_in_original_units = tiny$bootstrap_se / 1e-200,
  ordinary_SE = ordinary$bootstrap_se)

## -----------------------------------------------------------------------------
bootstrap$lower <= 2 && 2 <= bootstrap$upper

## -----------------------------------------------------------------------------
sessionInfo()

