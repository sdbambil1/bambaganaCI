## -----------------------------------------------------------------------------
library(bambaganaCI)
bambagana_catalog("confidence")
bambagana_catalog("regression")

## ----eval=FALSE---------------------------------------------------------------
# ?mean_t_ci

## -----------------------------------------------------------------------------
set.seed(1998)
scores <- c(8, 10, 12, 9, 15, 11, 13, 10, 14, 12)
describe_numeric(scores)

## -----------------------------------------------------------------------------
mean_se(scores)
mean_t_ci(scores)

## -----------------------------------------------------------------------------
set.seed(1998)
bootstrap_mean_ci(scores, B = 2000, method = "percentile")

## -----------------------------------------------------------------------------
p <- proportion_ci(successes = 40, trials = 100, method = "wilson")
p

## -----------------------------------------------------------------------------
p$estimate
coef(p)
confint(p)
as.data.frame(p)

## -----------------------------------------------------------------------------
proportion_ci(40, 100, conf = 0.90)

## -----------------------------------------------------------------------------
group1 <- c(8, 10, 12, 9, 15, 11, 13, 10, 14, 12)
group2 <- c(10, 12, 14, 13, 16, 14, 11, 15, 13, 12)
comparison <- mean_difference_ci(group1, group2)
comparison

## -----------------------------------------------------------------------------
mean_test(scores, mu = 10)

## -----------------------------------------------------------------------------
two_mean_test(group1, group2)

## -----------------------------------------------------------------------------
model <- ols_fit(mpg ~ wt + hp, data = mtcars)
ols_coef_ci(model)
ols_predict_ci(model, data.frame(wt = 3, hp = 150), interval = "confidence")
ols_predict_ci(model, data.frame(wt = 3, hp = 150), interval = "prediction")

## -----------------------------------------------------------------------------
sample_size_mean(delta = 0.5, sd = 1, power = 0.8)

## ----eval=FALSE---------------------------------------------------------------
# bambagana_catalog()
# sort(getNamespaceExports("bambaganaCI"))
# help(package = "bambaganaCI")
# help("proportion_ci", package = "bambaganaCI")
# example("proportion_ci", package = "bambaganaCI")
# vignette("getting-started", package = "bambaganaCI")

## ----bambagana-simple-input-guide---------------------------------------------
library(bambaganaCI)

scores <- c(65, 72, 68, 75, 70, 78, 74, 69, 73, 76)

# Mean confidence interval
bambagana("mean", scores)

# Test the hypothesis that the population mean equals 70
bambagana("test mean", scores, mu = 70)

# Proportion: successes first, trials second
bambagana("proportion", c(65, 100))

# Compare independent proportions
bambagana("compare proportions", c(65, 100), c(45, 100))

## ----bambagana-group-examples-------------------------------------------------
group_A <- c(65, 72, 68, 75, 70, 78, 74, 69, 73, 76)
group_B <- c(71, 79, 75, 82, 77, 85, 80, 74, 78, 81)

bambagana("compare means", group_A, group_B)
bambagana("test two means", group_A, group_B)

## ----bambagana-result-access--------------------------------------------------
result <- bambagana("mean", scores, display = FALSE)

result$estimate
result$lower
result$upper

## ----bambagana-descriptive-output---------------------------------------------
bambagana("describe", scores)

## ----full-bambagana-catalog---------------------------------------------------
functions <- bambagana("all functions", display = FALSE)
head(functions)

